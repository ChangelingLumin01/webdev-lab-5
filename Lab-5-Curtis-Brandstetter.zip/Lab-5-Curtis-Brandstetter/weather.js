let weather = {
    sunday: {
        temperature: 8,
        humidity: 30,
        sky: "sunny",
        photo: "sunny.jpg"
    },
    monday: {
        temperature: 10,
        humidity: 45,
        sky: "scattered clouds",
        photo: "scattered.jpg"
    },
    tuesday: {
        temperature: 5,
        humidity: 65,
        sky: "cloudy",
        photo: "cloudy.jpg"
    },
    wednesday: {
        temperature: -2,
        humidity: 25,
        sky: "overcast",
        photo: "overcast.jpg"
    },
    thursday: {
        temperature: -1,
        humidity: 42,
        sky: "snowy",
        photo: "snowy.jpg"
    },
    friday: {
        temperature: 0,
        humidity: 55,
        sky: "freezing rain",
        photo: "freezing.jpg"
    },
    saturday: {
        temperature: 3,
        humidity: 37,
        sky: "cloudy",
        photo: "cloudy.jpg"
    }
}

//Exporting the "weather" object so it can be used
//with any app
module.exports = weather