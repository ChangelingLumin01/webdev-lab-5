//Week-6 Working more with ejs 
//Let's import express
const { response } = require("express")
const express = require("express")
const { request } = require("http")
//Let's import module from weather.js
const weather = require("./weather.js")
//Let's import car module
const car = require("./car.js")
const exp = require("constants")
const app = express()
//Set up get to use ejs engine with express
app.set("view engine", "ejs")
app.use(express.static("public"))
const port = 3000
app.listen(port)
console.log(`Listening on port ${port}`)

app.get("/", (request, response) => {
    response.send("Welcome to the root page")
})

//to go to the weather page we have to add it to the route string
app.get("/weather", (request, response)=>{
    
    if(request.query.day === undefined){
        response.render("weatherHome")
    }
    else{
        day = request.query.day.toLowerCase()//make sure that the day will be read correctly from the module by having the same case.
        weatherOfDay = weather[day]// it has to be square brackets notation to work with querys (you cannot use weather.day because day is a string)
        if(weatherOfDay === undefined){
            response.status(404).render("404Page") // check if the query entered is a key in weather module
        }
        else{
            //NEW STUFF: We change from .send to .render
            //we pass through a ejs template named "weatherPage" and weatherOfDay, which is the object that contains the data of the day obtained from the query.
            //The code that was here went to weatherPage.ejs in views folder
            response.render("weatherPage", weatherOfDay)
            
        }
    }
})


//car page route
app.get("/car", (request, response) => {
    cartype = request.query.cartype
    if(cartype === undefined){
        response.render("carHome")
    }
    else{
        
        carFromModule = car[cartype.toLowerCase()]
        if(carFromModule === undefined){
            response.status(404).render("404Page")
        }
        else{
            response.render("carPage", carFromModule)
        }
    }
})