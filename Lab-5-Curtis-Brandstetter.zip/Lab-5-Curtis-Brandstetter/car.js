let car = {
    truck: {
        passengers: 5,
        doors: 4,
        availableColor: {
            red: 5,
            black: 2,
            green: 1
        }
    },

    sedan: {
        passengers: 5,
        doors: 2,
        availableColor: {
            pink: 0,
            green: 3,
            yellow: 10
        }

    },

    suv: {
        passengers: 7,
        doors: 5,
        availableColor: {
            silver: 5,
            brown: 2,
            black: 1
        }

    },
}

module.exports = car